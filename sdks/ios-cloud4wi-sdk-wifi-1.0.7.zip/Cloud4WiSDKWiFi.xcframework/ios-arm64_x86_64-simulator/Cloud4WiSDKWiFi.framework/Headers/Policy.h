//
//  Policy.h
//  Cloud4WiSDKWiFi
//

#ifndef Policy_h
#define Policy_h

@interface Policy : NSObject

@property NSString *id;
@property NSString *name;
@property NSNumber *required;

@end


#endif /* Policy_h */
